# TAFP-GraphRAG V10 External Artifacts Final QA

- Overall status: PASS_EXTERNAL_ARTIFACT_IDENTITY_AND_MANUSCRIPT_SUPPLEMENT_CONSISTENCY_WITH_EXTERNAL_ARCHIVE_BOUNDARIES
- Handoff SHA-256: `1b51458609424e4873da057884e0289922fea05ab1f5ddfdc5dd667c4a397bfb`
- Canonical supplementary SHA-256: `6e768a2ad4fdf84ea8de203ee19a71d74097adbb1815aa79b45bc2c87fbc16cc`
- Canonical supplementary CRC: PASS
- Physical supplementary CSVs: 31
- Logical supplementary items: 28
- Logical range: S1-S18 and S20-S29
- S19: intentionally absent
- Mapping and internal-manifest records verified: 31/31
- Figure source files: 7/7
- Source-to-V10 embedded byte matches: 7/7
- Manuscript supplementary citation paragraphs audited: 14
- Claim audit failures: 0
- Manuscript changes applied: 0

## Automation correction

The initial paragraph-231 FAIL was caused by a comparison-label mismatch in the audit script. Revalidation using the exact S18 labels `full_vs_dk2_full_budget` and `dk2_vs_random_full_budget` passed. No data or manuscript inconsistency was found.

## External evidence boundaries

1. Paragraph 231 replication execution/replay diagnostics require the immutable execution archive.
2. Paragraph 264 parse-success-only sensitivity equivalence requires the analysis archive or sensitivity-output artifact.
3. Paragraph 304 immutable experiment-archive linkage extends beyond the delivered package.

These are evidence-scope boundaries, not detected contradictions.

## Figure-format boundary

The delivered figure sources are exactly the same binaries embedded in V10. Journal-specific resolution/DPI compliance has not yet been assessed against the current JISA author guidelines.
