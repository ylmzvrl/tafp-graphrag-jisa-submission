# TAFP JISA Reference Verification Summary V1

- Total references: 46
- PARTIAL_PRIMARY_SOURCE_FOUND: 19
- VERIFIED_ACCEPTED_PREPUBLICATION: 1
- VERIFIED_MATCH: 25
- VERIFIED_WITH_STYLE_DETAIL: 1
- Evidence-backed correction proposals: 7
- Manuscript edits applied: 0
- Scientific text changes: 0
- Unsupported assumptions: 0

## Proposed changes
- Ref 5 (Osipjan et al., 2025): OPTIONAL_STYLE_ONLY: include issue 9 if JISA reference style retains issue numbers
- Ref 19 (Ning et al., 2026): OPTIONAL_STYLE_ONLY: include issue 38 if JISA reference style retains issue numbers
- Ref 23 (Jia et al., 2026): OPTIONAL_STYLE_ONLY: include issue 27 if JISA reference style retains issue numbers
- Ref 25 (Hu et al., 2022): OPTIONAL_STYLE_ONLY: include issue 11s if JISA reference style retains issue numbers
- Ref 32 (Hidano and Murakami, 2024): OPTIONAL_STYLE_ONLY: include issue 2 if JISA reference style retains issue numbers
- Ref 36 (Casas-Roma, 2020): OPTIONAL_STYLE_ONLY: include issue 4 if JISA reference style retains issue numbers
- Ref 40 (Cohan et al., 2018): STYLE_COMPLETENESS_ONLY: official proceedings title includes '(Short Papers)'
