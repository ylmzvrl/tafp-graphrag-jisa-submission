# TAFP-GraphRAG V10 JISA Guideline Audit

Status: PARTIAL_PASS_SUBMISSION_BLOCKERS_REMAIN

## Passed

- JISA scope alignment
- Single-anonymized review: author identity may remain
- Editable single-column DOCX
- 182-word abstract, below the 250-word limit
- Six keywords, within the 1–7 range
- Numbered article structure
- Editable equations and nine editable tables
- Sequential citations and captions for Tables 1–9 and Figures 1–7
- Complete, verified supplementary package S1–S18 and S20–S29
- CRediT, funding, ethics, data, code, AI-use, acknowledgments, and competing-interest sections are present
- Reference and citation-claim audits pass
- Zero comments or tracked changes

## Submission blockers

1. Figures 1–7 are raster diagrams/charts at approximately 251–612 dpi at their current 6.65-inch placement. JISA requires 1000 dpi for bitmapped line drawings, or vector EPS/PDF.
2. JISA research-data Option C requires a repository link and citation, or a specific explanation of why data cannot be shared.
3. Corresponding-author full street address and phone number are not available.
4. A separate Elsevier competing-interest DOCX has not been confirmed/generated.
5. The required author biography and passport-type photograph are missing.

## Minor V11 edits

- Remove TableGrid vertical rules
- Move Acknowledgments directly before References
- Standardize the no-funding statement
- Use Elsevier's exact generative-AI declaration heading
- Finalize data/code availability wording

## Optional items

- Highlights: compliant draft created
- Graphical abstract: encouraged but not required; omission is acceptable
