# Required user inputs before V11 and submission lock

1. Corresponding-author contact details
   - Full institutional street postal address
   - Phone number for Editorial Manager metadata

2. Author vitae
   - Biography of no more than 100 words
   - Passport-type author photograph as a separate image

3. Data and code availability decision
   - Public or reviewer-access repository URL/DOI for data, code, scripts, and reproducibility artifacts; or
   - A precise, truthful explanation of why the materials cannot be deposited/shared

4. Declaration confirmations
   - Confirm that there are no competing interests, or disclose them
   - Confirm that the research received no specific grant
   - Confirm that all figures/tables are original and require no third-party permission
   - Confirm that generative AI was not used to create or alter Figures 1–7

5. Figure production sources
   - Original plotting scripts, diagram source files, SVG/PDF/EPS originals, or editable source project
   - Current PNG files must not be merely upscaled
   - Target: vector PDF/EPS with embedded fonts, or raster exports at least 7480 px wide for the current full-page placement

6. Submission preference
   - Confirm whether the optional graphical abstract will be omitted
   - Confirm intended article type in Editorial Manager (expected: Research article)
