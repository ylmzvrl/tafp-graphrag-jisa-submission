# JISA submission file plan

## Files to upload to Editorial Manager

1. Main manuscript
   - Final V11 DOCX
   - Single-column, author identified, clean comments/tracked changes

2. Highlights
   - TAFP_JISA_Highlights.docx
   - Four bullets, each under 85 characters

3. Figures
   - Figure_1 through Figure_7 as separate vector PDF/EPS files
   - Raster fallback only if exported at compliant final resolution

4. Supplementary material
   - TAFP_Canonical_Supplementary_Tables_20260623.zip
   - TAFP_JISA_Supplementary_Material_Captions.docx

5. Declaration of competing interests
   - Separate DOCX generated through Elsevier's Declaration Tool after author confirmation

6. Author vitae
   - Biography DOCX, maximum 100 words
   - Passport-type author photograph

7. Optional files
   - Graphical abstract: omit unless a human-created compliant file is intentionally prepared
   - Cover letter: prepare after final claims, repository links, and declarations are locked

## V11 manuscript edits after inputs are received

- Replace all TableGrid formatting with minimal horizontal table rules
- Reorder back matter so Acknowledgments directly precedes References
- Use Elsevier's standard no-specific-grant funding wording
- Change the generative-AI declaration heading to the exact Elsevier title
- Finalize data and code availability wording with repository links or non-sharing rationale
- Add full postal address if the author approves inclusion in the manuscript
- Re-render all pages and repeat structural, citation, and artifact QA

## Internal-only files not normally uploaded

- Reference and citation audit ledgers
- Figure/supplement integrity reports
- SHA-256 manifests
- Submission lock report
