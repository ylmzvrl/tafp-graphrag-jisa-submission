# JISA Portal Upload Set

This directory contains the clean portal-facing manuscript and support files. Internal QA, lock, and audit artifacts are intentionally excluded.

Before the final Submit action, confirm the corresponding-author metadata in the portal and complete remote GitHub/Drive parity verification recorded in the separate final-lock package.
