# Section 6 Superseding Text-Level Lock

- Lock ID: `SECTION6_RESULTS_JISA_REVISED_LOCKED_V2`
- Supersedes: `SECTION6_RESULTS_JISA_REVISED_LOCKED_V1`
- Scope: four editorial cross-reference sentences calling Table 3, Table 6, and Figures 4–7.
- Scientific/numeric change: none.
- User approval: explicit.
