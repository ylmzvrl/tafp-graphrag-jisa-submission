# Remote Synchronization Required

The local final lock is complete. Authenticated remote write access was not available in the artifact-generation environment.

Before portal submission:

1. Synchronize this exact final lock to the authorized Google Drive project location.
2. Synchronize the matching submission set to `ylmzvrl/tafp-graphrag-jisa-submission`.
3. Update the GitHub repository About description from `Private JISA submission-only package...` to a public-scope description.
4. Verify relative path, byte size, and SHA-256 parity across local final lock, Drive, and GitHub.
5. Create a superseding final tag only after parity passes; do not move or overwrite `jisa-submission-final-v1`.
