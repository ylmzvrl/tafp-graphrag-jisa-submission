# Public Repository Release Record

Repository: `ylmzvrl/tafp-graphrag-jisa-submission`

Observed public state on 2026-06-30:

- Repository visibility: public and anonymously readable.
- Public main HEAD before this local final-lock package: `c1e47c3fb47062b8050c8b303591658f4bc20e24`.
- Existing immutable tag from the prior canonical package: `jisa-submission-final-v1`.
- Repository scope: submission-support and reproducibility artifacts; not a complete public release of implementation and evaluation code.

This `TAFP_JISA_FINAL_LOCK_20260630` package has not yet been pushed to GitHub or synchronized to Google Drive. Remote parity must be established by authenticated upload and exact post-upload SHA-256 verification before portal submission.
