# TAFP-GraphRAG JISA Final Submission Lock

Date: 2026-06-30

## Locked identities

- Full manuscript lock:   `TAFP_JISA_FULL_MANUSCRIPT_FINAL_LOCKED_V1`
- Manuscript TEX SHA-256:   `28db11ff14e2baa4f6131e9a266bc0e78f8bc1009053d73b135a3299f27ce985`
- Retained manuscript PDF SHA-256:   `f514db5c4dcacda842d27f104adbdfaaca39e5bc16d1e49a148d88547ae54b9c`
- Clean final source ZIP SHA-256:   `11a4bdb48cff6398c353b6b7e307a48534b2e98e63a398ea4eb26c1033684cef`
- Superseding Results lock:   `SECTION6_RESULTS_JISA_REVISED_LOCKED_V2`
- Section 6 lock SHA-256:   `1447e33b7148249ce3d4793336b76ada27cfe8c96fc5ebaf7c13e9d71f776c15`

## Final QA

- Fresh source rebuild: PASS
- Fresh BibTeX: PASS
- PDF pages: 63
- LaTeX errors/warnings: 0/0
- Undefined citations/references: 0/0
- Overfull hbox: 0
- Underfull hbox: 9, nonblocking
- Retained PDF vs fresh source rebuild visual parity: 0 changed pages / 63
- All ten section locks occur exactly once in the final manuscript: PASS
- Support DOCX metadata render QA: PASS
- Declaration active comments: 0
- Tracked changes in support DOCX files: 0

## Scope

The final text contains no newly fabricated result, number, mechanism, baseline, citation, causal statement, or privacy guarantee. Section 6 V2 differs from V1 only by four approved editorial cross-reference sentences.

## Remote state

The local final lock is complete. GitHub and Google Drive have not been updated from this environment because authenticated remote write access was unavailable. Remote path/size/SHA-256 parity and a superseding immutable tag remain required before portal submission.
