# TAFP-GraphRAG JISA Full-Manuscript Final Review Report

Date: 2026-06-30  
Review status: **QA PASS — USER FINAL APPROVAL REQUIRED — NOT LOCKED — NOT INTEGRATED INTO CANONICAL — NOT TAGGED**

## 1. Authoritative identities

- Immutable baseline handoff SHA-256: `14c5c91cd8125114df0e91e9fd691ac6c102e62620e24fb51571dce0f24591fe`
- Canonical baseline manuscript SHA-256: `325a09683bf96ad80b27f813e381fc9c6a4d0ed6ab5e7393db556196ae742763`
- Final Candidate V2 LaTeX SHA-256: `28db11ff14e2baa4f6131e9a266bc0e78f8bc1009053d73b135a3299f27ce985`
- Final Candidate V2 PDF SHA-256: `f514db5c4dcacda842d27f104adbdfaaca39e5bc16d1e49a148d88547ae54b9c`
- `references.bib` SHA-256: `2c0c6e27ba0826c37c6cae2f3c54092733dd4514b49f966c7880b4ebdac2ced4` (unchanged)

The candidate was assembled from the ten user-approved text-level locks and the reviewed canonical frontmatter/backmatter. It was not reconstructed from pasted chat text.

## 2. Only pending post-lock editorial change

A whole-manuscript audit against the current official JISA Guide for Authors identified one real editorial compliance gap: Table 3, Table 6, and Figures 4-7 lacked explicit main-text calls. Candidate V2 adds exactly four short cross-reference sentences in Results. These sentences:

- introduce no numerical value;
- change no scientific predicate, comparison direction, result, mechanism, or scope boundary;
- modify no table row, figure caption, citation key, or bibliography entry;
- make all 9 tables and all 7 figures explicitly cited in the main text.

The integrated Results section is byte-identical to `SECTION6_RESULTS_JISA_REVISED_LOCKED_V1` after removing exactly these four sentences. Therefore a superseding `SECTION6_RESULTS_JISA_REVISED_LOCKED_V2` requires explicit user approval before final lock/integration.

## 3. Whole-manuscript mechanical QA

- Abstract: 198 words
- Keywords: 6
- Main sections: 9
- Subsections: 28
- Longtables: 9
- Figures: 7
- Display equations: 4
- Citation groups / occurrences / unique keys: 33 / 98 / 46
- Bibliography entries: 46
- Undefined citations / references: 0 / 0
- Uncited bibliography entries: 0
- Duplicate labels / normalized titles / DOIs: 0 / 0 / 0
- Longtable column-schema mismatches: 0 across 9 tables
- Exact duplicate substantive sentences detected: 0

## 4. Fresh build and visual QA

Build sequence: `pdflatex -> bibtex8 -> pdflatex -> pdflatex`

- PDF pages: 63
- LaTeX errors / warnings: 0 / 0
- Undefined citations / references: 0 / 0
- Multiply defined labels: 0
- Overfull hboxes: 0
- Underfull hboxes: 9, nonblocking
- Fonts embedded: PASS
- Pages visually inspected: 1-63
- Clipping, overlap, broken glyphs, unreadable tables, or page-layout defects: 0

The clean source ZIP was independently extracted and rebuilt with `pdflatex -> bibtex8 -> pdflatex -> pdflatex`: 63 pages, 0 errors, 0 warnings, 0 undefined citations/references, and 0 overfull hboxes. The regenerated PDF has a different byte hash because build metadata/time is regenerated; source identity and compile outcomes match.

All seven figure PDFs were rendered independently and inspected. Every figure is one page, uses embedded fonts, and has no clipped label, broken glyph, overlap, or unreadable element.

## 5. Scientific-integrity judgment

The final candidate preserves all approved numerical results, attack/protocol boundaries, matched-random qualifications, degree-preservation scope, marker-leakage boundary, policy-misclassification boundary, evaluation-layer distinctions, and formal-privacy non-claims. No experiment, result, baseline, model, mechanism, citation, or privacy guarantee was invented or added.

The manuscript continues to state that attack outcomes are dataset- and attacker-dependent; matched random controls remain competitive in several settings; exact degree preservation applies only to designated variants and does not imply higher-order topology invariance or privacy; `PRIVATE_RELATION` does not hide policy membership; and the work does not establish formal DP/LDP, universal privacy, raw-text privacy, edge privacy, topology privacy, or complete anonymization.

## 6. Current JISA submission-compliance review

Checked against the official JISA Guide for Authors on 2026-06-30:

- Abstract maximum 250 words: PASS (198)
- Keywords 1-7: PASS (6)
- Highlights 3-5 and at most 85 characters each: PASS (4; 70, 55, 55, 58)
- All tables cited in text: PASS after the pending four-sentence cross-reference microfix
- All images cited in text: PASS after the pending four-sentence cross-reference microfix
- Editable biography at most 100 words: PASS (92 body words)
- Separate author photograph: PASS
- Funding, competing-interest, ethics, data, code, AI-use, and acknowledgments statements: present and coherent
- AI-use declaration is placed before the references: PASS

## 7. Submission-support files

The six editable DOCX support files were rendered and visually inspected page by page (9 pages total). No clipping, overlap, broken glyph, or unreadable table was found. Tracked changes: 0. The official competing-interest document contains zero active comments and remains unmodified.

The supplementary ZIP has SHA-256 `6e768a2ad4fdf84ea8de203ee19a71d74097adbb1815aa79b45bc2c87fbc16cc`, passes CRC, contains 33 physical files, and represents logical Tables S1-S18 and S20-S29; S19 is explicitly and consistently absent.

## 8. Final professional judgment

`TAFP_JISA_FULL_MANUSCRIPT_FINAL_CANDIDATE_V2` is scientifically coherent, mechanically clean, visually clean, citation-complete, and submission-ready **subject to one explicit user approval**: acceptance of the four Results cross-reference sentences and creation of a superseding Section 6 lock. Until that approval, the candidate must not be called `LOCKED`, integrated into the canonical manuscript, pushed as the final synchronized revision, or tagged.
